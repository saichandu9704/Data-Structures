 
#include "main.h"

int Postfix_Eval(char *Postfix_exp, Stack_t *stk)
{
    int j=0,op1,op2,result;
    while(Postfix_exp[j]!='\0')
    {
        if(Postfix_exp[j]>='0' && Postfix_exp[j]<='9')
        {
            push(stk,(Postfix_exp[j]-'0'));
            j++;
        }
        else
        {
            op2=peek(stk);
            pop(stk);
            op1=peek(stk);
            pop(stk);
            switch(Postfix_exp[j])
            {
                case '+':
                result=op1+op2;
                push(stk,result);
                break;
                case '-':
                result=op1-op2;
                push(stk,result);
                break;
                case '*':
                result=op1*op2;
                push(stk,result);
                break;
                case '/':
                result=op1/op2;
                push(stk,result);
                break;
            }
            j++;
        }
    }
    return peek(stk);
}