#include "main.h"

int Prefix_Eval(char *Prefix_exp, Stack_t *stk)
{
    int j=0,op1,op2,result;
    while(Prefix_exp[j]!='\0')
    {
        if(Prefix_exp[j]>='0' && Prefix_exp[j]<='9')
        {
            push(stk,Prefix_exp[j]-'0');
            j++;
        }
        else
        {
            op1=peek(stk);pop(stk);
            op2=peek(stk);pop(stk);
            switch(Prefix_exp[j])
            {
                case '+':
                result=op1+op2;
                push(stk,result);
                break;
                case '-':
                result=op1-op2;
                push(stk,result);
                break;
                case '*':
                result=op1*op2;
                push(stk,result);
                break;
                case '/':
                result=op1/op2;
                push(stk,result);
                break;
            }
            j++;
        }
    }
    return peek(stk);
}