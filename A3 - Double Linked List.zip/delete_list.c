#include "dll.h"

int dl_delete_list(Dlist **head, Dlist **tail)
{
    if(*head==NULL && *tail==NULL)
    {
        return FAILURE;
    }
    if(*head==*tail)
    {
        free(*head);
        *head=NULL;
        *tail=NULL;
        return SUCCESS;
    }
    Dlist *temp=*head;
    while(head!=NULL)
    {
        temp=*head;
        *head=(*head)->next;
        if(*head==*tail)
        {
            free(temp);
            *head=NULL;
            *tail=NULL;
            return SUCCESS;
        }
        (*head)->prev=NULL;
        free(temp);
    }
    *head=NULL;
    *tail=NULL;
    return SUCCESS;
}