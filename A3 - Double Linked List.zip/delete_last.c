#include "dll.h"

int dl_delete_last(Dlist **head, Dlist **tail)
{
    if(*head==NULL && *tail==NULL)
    {
        return FAILURE;
    }
    if(*head==*tail)
    {
        free(*tail);
        *head=NULL;
        *tail=NULL;
        return SUCCESS;
    }
    Dlist *temp=*tail;
    *tail=(*tail)->prev;
    (*tail)->next=NULL;
    free(temp);
    return SUCCESS;
}