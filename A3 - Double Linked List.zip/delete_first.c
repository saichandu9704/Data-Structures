#include "dll.h"

int dl_delete_first(Dlist **head, Dlist **tail)
{
    if(*head==NULL && *tail==NULL)
    {
        return FAILURE;
    }
    if(*head==*tail)
    {
        free(*head);
        *head=NULL;
        *tail=NULL;
        return SUCCESS;
    }
    Dlist *temp=*head;
    *head=(*head)->next;
    (*head)->prev=NULL;
    free(temp);
    return SUCCESS;
}