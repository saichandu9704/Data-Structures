#include "dll.h"

int dl_insert_after(Dlist **head, Dlist **tail, int gdata, int ndata)
{
    if(*head==NULL && *tail==NULL)
    {
        return LIST_EMPTY;
    }
    Dlist *new=malloc(sizeof(Dlist));
    if(new==NULL)
    {
        return FAILURE;
    }
    new->data=ndata;
    new->prev=NULL;
    new->next=NULL;
    Dlist *temp=*head;
    while(temp!=NULL)
    {
        if(temp==*tail)
        {
            if(temp->data==gdata)
            {
                new->prev=temp;
                temp->next=new;
                *tail=new;
                return SUCCESS;
            }
        }
        if(temp->data==gdata)
        {
            new->prev=temp;
            new->next=temp->next;
            temp->next->prev=new;
            temp->next=new;
            return SUCCESS;
        }
        temp=temp->next;
    }
    return DATA_NOT_FOUND;
}