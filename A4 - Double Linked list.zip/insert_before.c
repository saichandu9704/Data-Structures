#include "dll.h"

int dl_insert_before(Dlist **head, Dlist **tail, int gdata, int ndata)
{
    if(*head==NULL && *tail==NULL)
    {
        return LIST_EMPTY;
    }
    Dlist *new=malloc(sizeof(Dlist));
    if(new==NULL)
    {
        return FAILURE;
    }
    new->data=ndata;
    new->prev=NULL;
    new->next=NULL;
    Dlist *temp=*tail;
    while(temp!=NULL)
    {
        if(temp==(*head))
        {
            if(temp->data==gdata)
            {
                new->next=temp;
                temp->prev=new;
                *head=new;
                return SUCCESS;
            }
        }
        if(temp->data==gdata)
        {
            new->next=temp;
            new->prev=temp->prev;
            temp->prev->next=new;
            temp->prev=new;
            return SUCCESS;
        }
        temp=temp->prev;
    }
    return DATA_NOT_FOUND;
}