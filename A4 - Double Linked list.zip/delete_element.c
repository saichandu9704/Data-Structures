#include "dll.h"

int dl_delete_element(Dlist **head, Dlist **tail, int data)
{	
    if(*head==NULL && *tail==NULL)
    {
        return LIST_EMPTY;
    }
    if(*head==*tail)
    {
        if((*head)->data==data)
        {
            free(*head);
            *head=NULL;
            *tail=NULL;
            return SUCCESS;
        }
    }
    Dlist *temp=*head;
    while(temp!=NULL )
    {
        if(temp->data==data)
        {
            if(temp==*head)
            {
                *head=(*head)->next;
                (*head)->prev=NULL;
                free(temp);
                return SUCCESS;
            }
            if(temp==*tail)
            {
                *tail=(*tail)->prev;
                (*tail)->next=NULL;
                free(temp);
                return SUCCESS;
            }
            temp->prev->next=temp->next;
            temp->next->prev=temp->prev;
            return SUCCESS;
        }
        temp=temp->next;
    }
    return DATA_NOT_FOUND;
}