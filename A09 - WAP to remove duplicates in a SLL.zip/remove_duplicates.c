#include "sll.h"

//remove duplicate data's from list
int remove_duplicates( Slist **head )
{

}