#include "sll.h"
/* Function to get the middle of the linked list*/
int find_mid(Slist *head, int *mid) 
{ 
    if(head==NULL)
    {
        return LIST_EMPTY;
    }
    Slist *fast=head;
    while(head!=NULL)
    {
        head=head->link;
        if(head!=NULL)
        {
            head=head->link;
            fast=fast->link;
        }
    }
    *mid=fast->data;
    return SUCCESS;
} 