#include "sll.h"
/* Function to get the nth node from the last of a linked list*/
int find_nth_last(Slist *head, int pos, int *data) 
{ 
    if(head==NULL)
    {
        return LIST_EMPTY;
    }
    Slist *fast=head;
    Slist *slow=head;
    if(pos==0)
    {
        return FAILURE;
    }
    for(int i=0;i<(pos-1);i++)
    {
        fast=fast->link;
        if(fast==NULL)
        {
            return FAILURE;
        }
    }
    while((fast->link)!=NULL)
    {
        slow=slow->link;
        fast=fast->link;
    }
    *data=slow->data;
    return SUCCESS;
} 