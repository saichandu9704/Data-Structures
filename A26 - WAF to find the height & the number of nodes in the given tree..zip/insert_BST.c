#include "tree.h"

/* Function to insert the data's in BST */
int insert_into_BST(Tree_t **root, int data)
{
    Tree_t *new=malloc(sizeof(Tree_t));
    if(new==NULL)
    {
        return FAILURE;
    }
    new->data=data;
    new->left=NULL;
    new->right=NULL;
    if(*root==NULL)
    {
        *root=new;
        return SUCCESS;
    }
    Tree_t *temp=*root;
    Tree_t *prev=NULL;
    while(temp!=NULL)
    {
        prev=temp;
        if(temp->data>data)
        {
            temp=temp->left;
        }
        else if(temp->data<data)
        {
            temp=temp->right;
        }
        else
        {
            return DUPLICATE;
        }
    }
    if(prev->data>data)
    {
        prev->left=new;
    }
    else
    {
        prev->right=new;
    }
    return SUCCESS;
}