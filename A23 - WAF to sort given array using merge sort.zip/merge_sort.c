#include "main.h"


int merge_sort(int *array, int narray)
{
    if(narray>1)
    {
        int mid=(narray)/2;
        int *left=malloc(mid*sizeof(int));
        for(int i=0;i<mid;i++)
        {
            left[i]=array[i];
        }
        int *right=malloc((narray-mid)*sizeof(int));
        for(int i=mid;i<narray;i++)
        {
            right[i-mid]=array[i];
        }
        merge_sort(left,mid);
        merge_sort(right,narray-mid);
        merge(array,narray,left,mid,right,narray-mid);
    }
}
