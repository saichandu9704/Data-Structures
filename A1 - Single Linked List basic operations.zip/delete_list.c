#include "sll.h"

int sl_delete_list(Slist **head)
{
	if(*head==NULL)
	{
	    return FAILURE;
	}
	while(*head!=NULL)
	{
	    Slist *temp=*head;
	    *head=temp->link;
	    free(temp);
	}
}