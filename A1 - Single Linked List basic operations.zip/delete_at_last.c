#include "sll.h"

int sl_delete_last(Slist **head)
{
    if(*head==NULL)
    {
        return FAILURE;
    }
    if((*head)->link==NULL)
    {
        *head=NULL;
        return SUCCESS;
    }
    else
    {
        Slist *temp=*head;
        Slist *pre;
        while(temp->link!=NULL)
        {
            pre=temp;
            temp=temp->link;
        }
        pre->link=NULL;
        free(temp);
    }
}