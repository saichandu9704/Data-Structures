#include "sll.h"

int find_node(Slist *head, data_t data)
{
	if(head==NULL)
	{
	    return FAILURE;
	}
	int i=1;
	while(head!=NULL)
	{
	    if(head->data==data)
	    {
	        return i;
	    }
	    else
	    {
	        i++;
	        head=head->link;
	    }
	}
	return FAILURE;
}
