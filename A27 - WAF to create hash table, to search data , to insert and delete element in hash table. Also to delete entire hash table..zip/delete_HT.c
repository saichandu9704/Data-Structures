#include"hash.h"

int destroy_HT(hash_t *arr, int size)
{
    for(int i=0;i<size;i++)
    {
        if(arr[i].value!=-1)
        {
            hash_t *temp=arr[i].link;
            while(temp!=NULL)
            {
                hash_t *temp1=temp->link;
                free(temp);
                temp=temp1;
            }
        }
        arr[i].value=-1;
        arr[i].link=NULL;
    }
    return SUCCESS;
}