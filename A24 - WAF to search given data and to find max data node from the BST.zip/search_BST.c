#include "tree.h"

/* Iteratively */
int search_BST(Tree_t * root, int data)
{
    if(root==NULL)
    {
        return FAILURE;
    }
    while(root!=NULL)
    {
        if(root->data>data)
        {
            root=root->left;
        }
        else if(root->data<data)
        {
            root=root->right;
        }
        else
        {
            return SUCCESS;
        }
    }
    return NOELEMENT;
}
