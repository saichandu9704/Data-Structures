#include "tree.h"

int findmax(Tree_t * root)
{
    if(root==NULL)
    {
        return FAILURE;
    }
    Tree_t *prev=root;
    while(root!=NULL)
    {
        prev=root;
        root=root->right;
    }
    return prev->data;
}
