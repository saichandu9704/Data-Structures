#include "tree.h"

int findmin(Tree_t * root)
{
    if(root==NULL)
    {
        return FAILURE;
    }
    Tree_t *prev=root;
    while(root!=NULL)
    {
        prev=root;
        root=root->left;
    }
    return prev->data;
}
