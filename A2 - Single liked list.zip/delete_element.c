#include "sll.h"

int sl_delete_element(Slist **head, data_t data)
{
    if(*head==NULL)
    {
        return FAILURE;
    }
    Slist *temp=*head;
    if(temp->link==NULL)
    {
        if(temp->data==data)
        {
            *head=NULL;
            free(temp);
            return SUCCESS;
        }
        return DATA_NOT_FOUND;
    }
    Slist *pre=temp;
    if(pre->data==data)
    {
        temp=temp->link;
        free(pre);
        *head=temp;
        return SUCCESS;
    }
    while(temp!=NULL)
    {
        if(temp->data==data)
        {
            pre->link=temp->link;
            free(temp);
            return SUCCESS;
        }
        pre=temp;
        temp=temp->link;
    }
    return DATA_NOT_FOUND;
}