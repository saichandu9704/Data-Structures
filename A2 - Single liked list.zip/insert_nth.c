#include "sll.h"

int sl_insert_nth(Slist **head, data_t data, data_t n)
{
    /*if(*head==NULL)
    {
        return LIST_EMPTY;
    }*/
    Slist *new=malloc(sizeof(Slist));
    if(new==NULL)
    {
        return FAILURE;
    }
    new->data=data;
    new->link=NULL;
    Slist *temp=*head;
    Slist *pre=temp;
    if(*head==NULL)
    {
        if(n==1)
        {
            *head=new;
            return SUCCESS;
        }
        else
        {
            return LIST_EMPTY;
        }
    }
    int i=1;
    if(i==n)
    {
        new->link=pre;
        *head=new;
        return SUCCESS;
    }
    for(i;i<n;i++)
    {
        if(temp==NULL)
        {
            return POSITION_NOT_FOUND;
        }
        pre=temp;
        temp=temp->link;
    }
    new->link=pre->link;
    pre->link=new;
    return SUCCESS;
}