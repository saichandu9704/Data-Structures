#include "sll.h"

int sl_insert_before(Slist **head, data_t g_data, data_t ndata)
{
    if(*head==NULL)
    {
        return LIST_EMPTY;
    }
    Slist *new=malloc(sizeof(Slist));
    if(new==NULL)
    {
        return FAILURE;
    }
    new->data=ndata;
    new->link=NULL;
    Slist *temp=*head;
    if(temp->data==g_data)
    {
        new->link=temp;
        *head=new;
        return SUCCESS;
    }
    Slist *pre=temp;
    while(temp!=NULL)
    {
        if(temp->data==g_data)
        {
            new->link=pre->link;
            pre->link=new;
            return SUCCESS;
        }
        pre=temp;
        temp=temp->link;
    }
    return DATA_NOT_FOUND;
}