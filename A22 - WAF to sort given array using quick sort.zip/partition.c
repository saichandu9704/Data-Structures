#include "main.h"

/* Function to partition the array */
int partition(int *arr, int first, int last)
{
    int pivot=first,p=first+1,q=last;
    while(p<=q)
    {
        while(arr[pivot]>=arr[p])
        {
            p++;
        }
        while(arr[pivot]<arr[q])
        {
            q--;
        }
        if(p<q)
        {
            int temp=arr[p];
            arr[p]=arr[q];
            arr[q]=temp;
        }
    }
    int temp=arr[pivot];
    arr[pivot]=arr[q];
    arr[q]=temp;
    return q;
}


